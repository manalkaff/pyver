import json, threading
from functools import partial
from socketserver import ThreadingMixIn
from http.server import HTTPServer
from .handler import Serv


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
	"""Handle requests in a separate thread."""


class ThreadedServer:
    
	def __init__(self, urls,  host, port):

		self.host = host
		self.port = port

		self.handler = partial(Serv, urls)
		self.httpd = ThreadedHTTPServer((self.host, self.port), self.handler)
		self.serveractive = False
		self.server_thread = threading.Thread(target=self.httpd.serve_forever)



	def startserver(self):
		
		if not self.server_thread.is_alive():
			self.serveractive = True
			self.server_thread.start()
			return True
		else:
			return False

	def stopserver(self):

		if self.serveractive:
			self.httpd.shutdown()
			self.httpd.server_close()
			self.server_thread._stop()
			self.serveractive = False
			return True
		else:
			return False
